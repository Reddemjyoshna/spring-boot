package com.cg.question4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Question4Application {

	public static void main(String[] args) {
		SpringApplication.run(Question4Application.class, args);
	}

}
